async function refreshStatus() {
  const backend = document.getElementById('backend');
  try {
    const response = await fetch('/api/brokers');
    if (!response.ok) throw new Error('Backend response ' + response.status);
    const data = await response.json();
    backend.textContent = 'BACKEND ONLINE';
    for (const item of data.brokers) {
      const id = item.name === 'HFM' ? 'hfm' : 'pu';
      document.getElementById(id).textContent =
        item.liveVerified ? 'LIVE VERIFIED' : 'NOT CONNECTED';
      document.getElementById(id + 'msg').textContent = item.message;
    }
    document.getElementById('updated').textContent =
      'Last checked: ' + new Date().toLocaleString();
  } catch (error) {
    backend.textContent = 'BACKEND OFFLINE';
    document.getElementById('updated').textContent =
      'Could not reach backend: ' + error.message;
  }
}
refreshStatus();
</script>
